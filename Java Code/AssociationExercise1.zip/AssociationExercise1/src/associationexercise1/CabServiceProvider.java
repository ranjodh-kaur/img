//lex_auth_012907433000075264323
//do not modify the above line

package associationexercise1;

public class CabServiceProvider {
    //Implement your code here
}
